

package Animals

abstract class Animal {
    String name

    Animal(String name) {
        this.name = name
    }

    String describe() {
        return "This is a $name."
    }

    abstract String makeSound()
}


class Cat extends Animal {
    Cat(String name) {
        super(name)
    }

    @Override
    String makeSound() {
        "Meow"
    }
}

class Lion extends Animal {
    Lion(String name) {
        super(name)
    }

    @Override
    String makeSound() {
        "Silence"
    }
}

class Main {
    static void main(String[] args) {
        // Create instances of Dog, Cat, and Lion
        Animal dog = new Dog("Buddy")
        Animal cat = new Cat("Whiskers")
        Animal lion = new Lion("Simba")

        // Polymorphism: Treat Dog, Cat, and Lion as Animals
        List<Animal> animals = [dog, cat, lion]

        // Iterate over animals and call methods
        animals.each { animal ->
            println animal.describe()
            println "Sound: " + animal.makeSound()
            println ""
        }
    }
}

