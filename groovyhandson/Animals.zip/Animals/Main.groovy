class Main {
    static void main(String[] args) {
        // Create instances of Dog and Cat
         Animal dog = new Dog("Buddy")
         Animal cat = new Cat("Whiskers")

         // Polymorphism: Treat Dog and Cat as Animals
 List<Animal> animals = [dog, cat]

         Iterate over animals and call methods
         animals.each { animal ->
             println animal.describe()
            println "Sound: " + animal.makeSound()
             println ""
         }

       
    }
}
